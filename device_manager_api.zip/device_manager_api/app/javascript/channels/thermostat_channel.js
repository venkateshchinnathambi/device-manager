import consumer from "channels/consumer";

consumer.subscriptions.create("ThermostatChannel", {
  connected() {
    console.log("Connected to ThermostatChannel");
  },

  disconnected() {
    console.log("Disconnected from ThermostatChannel");
  },

  received(data) {
    console.log("Received data:", data);
    // You can update your DOM here based on the incoming data
    // Example: document.getElementById("some-id").innerText = data.temp;
     document.getElementById("thermostat-updates").innerText = data.ZoneName;
  }
});
