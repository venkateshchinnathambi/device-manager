import { createConsumer } from "@rails/actioncable"
console.log("consumer.js loaded!")
export default createConsumer()
