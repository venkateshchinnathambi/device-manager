class ThermostatsController < ApplicationController
  def index
   # ActionCable.server.broadcast("thermostat_channel",{mod_message: "somedata"} ) 
    render json: {message: "Thermostat Index ready"}
  end
end
