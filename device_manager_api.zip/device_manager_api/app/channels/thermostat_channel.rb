class ThermostatChannel < ApplicationCable::Channel
  def subscribed
     #stream_from "thermostat_updates"
     stream_from "thermostat_channel"
  end

  def unsubscribed
    # Any cleanup needed when channel is unsubscribed
  end
end
